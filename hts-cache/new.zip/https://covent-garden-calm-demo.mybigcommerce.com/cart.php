<!DOCTYPE html>
<html class="no-js" lang="en">
    <head>
        <title>Covent Garden Calm Demo - Shopping Cart</title>
        <link rel="dns-prefetch preconnect" href="https://cdn11.bigcommerce.com/s-w3d4ziaaha" crossorigin><link rel="dns-prefetch preconnect" href="https://fonts.googleapis.com" crossorigin><link rel="dns-prefetch preconnect" href="https://fonts.gstatic.com" crossorigin>
        
        
         

        <link href="https://cdn11.bigcommerce.com/r-6d3ad06da9906c7b44b28d560a43353105957b49/img/bc_favicon.ico" rel="shortcut icon">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="ft-name" content="Covent Garden">
        <meta name="ft-version" content="2.1.0">
        <meta name="ft-edition" content="Calm">

        <script>
            // Change document class from no-js to js so we can detect this in css
            document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
        </script>

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400|Work+Sans:300|Montserrat:400" rel="stylesheet">
        <link data-stencil-stylesheet href="https://cdn11.bigcommerce.com/s-w3d4ziaaha/stencil/282ab9e0-1112-0137-0bde-23fb93fa4dc9/css/theme-a46b1620-1798-0137-3b82-713a8ea2d633.css" rel="stylesheet">

        
<script type="text/javascript">
function beacon_deferred(beacon_api) { beacon_api.set_cookie_domain(".covent-garden-calm-demo.mybigcommerce.com");beacon_api.pageview({"isNew":0,"initiator":{"id":"","session_id":"e02cd2edcddfe27efcf8643c8e60ea884afc054c","type":"ANONYMOUS","visit_id":"828a4847-5f2d-49f5-814c-b92b6c07c0f0","visitor_id":"46e879b6-bf70-4f2b-93c6-7cd145ab4103"},"referer":{"url":"http:\/\/covent-garden-calm-demo.mybigcommerce.com\/"},"request":{"url":"https:\/\/covent-garden-calm-demo.mybigcommerce.com\/cart.php"}}, '', 3338318, "cart", {"customer":{"id":"anonymous"}}, '828a4847-5f2d-49f5-814c-b92b6c07c0f0', '46e879b6-bf70-4f2b-93c6-7cd145ab4103');}
</script>
<script type="text/javascript">
(function(){var d=document,g=d.createElement('script'),s=d.getElementsByTagName('script')[0];g.type='text/javascript';g.defer=true;g.src='https://cdn11.bigcommerce.com/r-6d3ad06da9906c7b44b28d560a43353105957b49/javascript/jirafe/beacon_api.js';s.parentNode.insertBefore(g,s);})();
</script>
<script type="text/javascript">
var BCData = {"csrf_token":"8a8980e5b085bcbd5776f1b76a70ce8eab1cb8afca1399603c2745a9d8e4ffae"};
</script>

        

        
        
        
        
        
        
        
        <!-- snippet location htmlhead -->
    </head>
    <body class="has-globalBanner">
        <!-- snippet location header -->
        <svg data-src="https://cdn11.bigcommerce.com/s-w3d4ziaaha/stencil/282ab9e0-1112-0137-0bde-23fb93fa4dc9/img/icon-sprite.svg" class="icons-svg-sprite"></svg>


        <header class="header  fixed-header-simple" role="banner">
    <a href="#" class="mobileMenu-toggle" data-mobile-menu-toggle="menu-mobile">
        <span class="mobileMenu-toggleIcon">Toggle menu</span>
    </a>
    <div class="header-top position--center header-simple">
        <nav class="navUser left">
    <ul class="navUser-section" >
            </ul>
</nav>
<nav class="navUser right ">
    <ul class="navUser-section navUser-section--alt">
        <li class="navUser-item navUser-item--search">
            <a class="navUser-action navUser-action--quickSearch" href="#" data-search="quickSearch" aria-controls="quickSearch" aria-expanded="false"><i class="icon" aria-hidden="true"><svg><use xlink:href="#icon-search" /></svg></i></a>
            <div class="dropdown dropdown--quickSearch" id="quickSearch" aria-hidden="true" tabindex="-1" data-prevent-quick-search-close>
                <div class="container">
    <!-- snippet location forms_search -->
    <form class="form" action="/search.php">
        <fieldset class="form-fieldset">
            <div class="form-field">
                <label class="is-srOnly" for="search_query">Search</label>
                <input class="form-input" data-search-quick name="search_query" id="search_query" data-error-message="Search field cannot be empty." placeholder="Search the store" autocomplete="off">
            </div>
        </fieldset>
    </form>
    <a class="modal-close" aria-label="Close" data-drop-down-close role="button">
        <span aria-hidden="true">&#215;</span>
    </a>
</div>
<div class="resultsContainer" id="qsResults">
    <section class="quickSearchResults" data-bind="html: results"></section>
</div>
            </div>
        </li>
        <li class="navUser-item">
            <a class="navUser-action" href="/wishlist.php"><i class="icon" aria-hidden="true"><svg><use xlink:href="#icon-heart" /></svg></i></a>
        </li>
        <li class="navUser-item navUser-item--account">
                    <a class="navUser-action" href="/login.php"><i class="icon" aria-hidden="true"><svg><use xlink:href="#icon-account" /></svg></i></a>
        </li>
        <li class="navUser-item navUser-item--comparison">
            <a class="navUser-action navUser-item--compare" href="/compare" data-compare-nav><i class="icon" aria-hidden="true"><svg><use xlink:href="#icon-compare" /></svg></i> <span class="countPill countPill--positive"></span></a>
        </li>
        <li class="navUser-item navUser-item--cart">
            <a
                class="navUser-action"
                data-cart-preview
                data-dropdown="cart-preview-dropdown"
                data-options="align:right"
                href="/cart.php">
                <span class="navUser-item-cartLabel"><i class="icon" aria-hidden="true"><svg><use xlink:href="#icon-bag" /></svg></i></span> <span class="countPill cart-quantity"></span>
            </a>

            <div class="dropdown-menu" id="cart-preview-dropdown" data-dropdown-content aria-hidden="true"></div>
        </li>
    </ul>
</nav>

        <div class="header-logo header-logo--center sticky ">
            <a href="https://covent-garden-calm-demo.mybigcommerce.com/" >
        <span class="header-logo-text with-image">
            <img class="header-logo-image svg-logo" data-sizes="auto" src="https://cdn11.bigcommerce.com/s-w3d4ziaaha/content/img/healthful-logo.svg" alt="Healthful" title="Healthful" width="200" height="50">
        </span>
</a>
        </div>

            <div class="navPages-container" id="menu" data-menu>
                <nav class="navPages " data-options="">
    <div class="navPages-quickSearch">
        <!-- snippet location forms_search -->
<form class="form"  action="/search.php">
    <fieldset class="form-fieldset">
        <div class="form-field">
            <label class="form-label is-srOnly" for="search_query_adv">Search Keyword:</label>
            <div class="form-prefixPostfix wrap">
                <input class="form-input" id="search_query_adv" name="search_query_adv" value="">
                <input class="button button--primary form-prefixPostfix-button--postfix" type="submit" value="Search">
            </div>
        </div>
    </fieldset>
</form>
    </div>
    <ul class="navPages-list navPages-list-depth-max simple">
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/deserts/">Deserts</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/juice/">Juice</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/breakfast/">Breakfast</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/meals/">Meals</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/snacks/">Snacks</a>
                        </li>
    </ul>
    <ul class="navPages-list navPages-list--user">
            <li class="navPages-item">
                <a class="navPages-action" href="/login.php">Sign in</a>
                    or <a class="navPages-action" href="/login.php?action=create_account">Register</a>
            </li>
    </ul>
</nav>
            </div>
    </div>

    <div data-content-region="header_bottom"></div>
        <div class="navPages-container navPages-mobile" id="menu-mobile" data-menu>
            <nav class="navPages " data-options="">
    <div class="navPages-quickSearch">
        <!-- snippet location forms_search -->
<form class="form"  action="/search.php">
    <fieldset class="form-fieldset">
        <div class="form-field">
            <label class="form-label is-srOnly" for="search_query_adv">Search Keyword:</label>
            <div class="form-prefixPostfix wrap">
                <input class="form-input" id="search_query_adv" name="search_query_adv" value="">
                <input class="button button--primary form-prefixPostfix-button--postfix" type="submit" value="Search">
            </div>
        </div>
    </fieldset>
</form>
    </div>
    <ul class="navPages-list navPages-list-depth-max simple">
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/deserts/">Deserts</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/juice/">Juice</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/breakfast/">Breakfast</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/meals/">Meals</a>
                        </li>
                        <li class="navPages-item">
                                <a class="navPages-action" href="https://covent-garden-calm-demo.mybigcommerce.com/snacks/">Snacks</a>
                        </li>
    </ul>
    <ul class="navPages-list navPages-list--user">
            <li class="navPages-item">
                <a class="navPages-action" href="/login.php">Sign in</a>
                    or <a class="navPages-action" href="/login.php?action=create_account">Register</a>
            </li>
    </ul>
</nav>
        </div>
        <div class="globalBanner" data-slick='{
    "arrows": false,
    "dots": false,
    "mobileFirst": true,
    "slidesToShow": 1,
    "slidesToScroll": 1,
    "autoplay": true,
    "responsive": [{
        "breakpoint": 900,
        "settings": "unslick"
    }]
}'>
        <span class="globalBanner-label">
            <a href="/juice/">
                <i class="globalBanner-icon fas fa-comment"></i> 
                Global Message Banner Included
            </a>
        </span>
        <span class="globalBanner-label">
            <a href="/breakfast/">
                <i class="globalBanner-icon fas fa-ship"></i> 
                Over 50 Icons to Choose From
            </a>
        </span>
        <span class="globalBanner-label">
            <a href="/meals/">
                <i class="globalBanner-icon fas fa-tag"></i> 
                Each Message Can Link to Content
            </a>
        </span>
</div>
</header>
        <div class="body has-globalBanner" data-currency-code="GBP">
     
    <div class="container">
        <div class="page">

    <main class="page-content" data-cart data-sticky-container>
        <ul class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">
        <li class="breadcrumb " itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                <a href="https://covent-garden-calm-demo.mybigcommerce.com/" class="breadcrumb-label" itemprop="item"><span itemprop="name">Home</span></a>
            <meta itemprop="position" content="0" />
        </li>
        <li class="breadcrumb is-active" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
                <a href="https://covent-garden-calm-demo.mybigcommerce.com/cart.php" class="breadcrumb-label" itemprop="item"><span itemprop="name">Your Cart</span></a>
            <meta itemprop="position" content="1" />
        </li>
</ul>

        <h1 class="page-heading" data-cart-page-title>
    <span>Your Cart (0 items)</span>
</h1>

        <div data-cart-status>
                    </div>

            <h3>Your cart is empty</h3>

        <!-- snippet location cart -->
    </main>
</div>

    </div>
    <div id="modal" class="modal" data-reveal data-prevent-quick-search-close>
    <a href="#" class="modal-close" aria-label="Close" role="button">
        <span aria-hidden="true">&#215;</span>
    </a>
    <div class="modal-content"></div>
    <div class="loadingOverlay"></div>
</div>
</div>
            <footer class="footer footer-simple" role="contentinfo">
        <div class="footer-simple-newsletter"
>
            <div class="container">
                <div class="footer-newsletter-info">
    <h5 class="footer-info-heading">Subscribe to our newsletter</h5>
    <p>Get the latest updates on new products and upcoming sales</p>
</div>

<form class="form" action="/subscribe.php" method="post">
    <fieldset class="form-fieldset">
        <input type="hidden" name="action" value="subscribe">
        <input type="hidden" name="nl_first_name" value="bc">
        <input type="hidden" name="check" value="1">
        <div class="form-field">
            <label class="form-label is-srOnly" for="nl_email">Email Address</label>
            <div class="form-prefixPostfix wrap">
                <input class="form-input" id="nl_email" name="nl_email" type="email" value="" placeholder="Your email address">
                <input class="button button--primary form-prefixPostfix-button--postfix" type="submit" value="Subscribe">
            </div>
        </div>
    </fieldset>
</form>
            </div>
        </div>
    <div class="footer-simple-info">
        <div class="container footer-simple-navigation"
>
            <ul class="footer-info-list">
                    <li>
                        <a href="https://covent-garden-calm-demo.mybigcommerce.com/shipping-returns/">Shipping &amp; Returns</a>
                    </li>
                    <li>
                        <a href="https://covent-garden-calm-demo.mybigcommerce.com/contact-us/">Contact Us</a>
                    </li>
                    <li>
                        <a href="https://covent-garden-calm-demo.mybigcommerce.com/articles/">Articles</a>
                    </li>
                    <li>
                        <a href="https://covent-garden-calm-demo.mybigcommerce.com/rss-syndication/">RSS Syndication</a>
                    </li>
                <li>
                    <a href="/sitemap.php">Sitemap</a>
                </li>
            </ul>
        </div>
            <h5 class="footer-info-heading">Connect With Us</h5>
                <ul class="socialLinks socialLinks--alt">
            <li class="socialLinks-item">
                    <a href="https://twitter.com" target="_blank">
                        <i class="icon icon--twitter"><svg><use xlink:href="#icon-twitter" /></svg></i>
                    </a>
            </li>
            <li class="socialLinks-item">
                    <a href="https://facebook.com" target="_blank">
                        <i class="icon icon--facebook"><svg><use xlink:href="#icon-facebook" /></svg></i>
                    </a>
            </li>
            <li class="socialLinks-item">
                    <a href="https://instagram.com" target="_blank">
                        <i class="icon icon--instagram"><svg><use xlink:href="#icon-instagram" /></svg></i>
                    </a>
            </li>
            <li class="socialLinks-item">
                    <a href="https://pinterest.com" target="_blank">
                        <i class="icon icon--pinterest"><svg><use xlink:href="#icon-pinterest" /></svg></i>
                    </a>
            </li>
            <li class="socialLinks-item">
                    <a href="https://youtube.com" target="_blank">
                        <i class="icon icon--youtube"><svg><use xlink:href="#icon-youtube" /></svg></i>
                    </a>
            </li>
            <li class="socialLinks-item">
                    <a href="https://plus.google.com" target="_blank">
                        <i class="icon icon--google"><svg><use xlink:href="#icon-google" /></svg></i>
                    </a>
            </li>
    </ul>
                    <div class="footer-payment-icons">
                <i class="pf pf-visa"></i>
                <i class="pf pf-mastercard-alt"></i>
                <i class="pf pf-american-express-alt"></i>
                <i class="pf pf-verified-by-visa"></i>
                <i class="pf pf-mastercard-securecode"></i>
                <i class="pf pf-amazon-pay-alt"></i>
                <i class="pf pf-apple-pay"></i>
                <i class="pf pf-paypal"></i>
                <i class="pf pf-klarna"></i>
        </div>
        <div class="footer-copyright">
                <div><a href="tel:0208 008 8008">Need help? Call us on 0208 008 8008</a></div>
            <address>1 Covent Garden,
London,
WC2E 8BE</address>
        </div>
            <div class="footer-copyright">
                <p class="powered-by">&copy; 2019 Covent Garden Calm Demo </p>
            </div>
            <div class="footer-copyright">
                <p class="powered-by">
                        <span>Designed by <a href="https://www.flairconsultancy.com?utm_source=store&amp;utm_medium=designedbyFlair" rel="nofollow" target="_blank">Flair</a>.</span>
                        <span>Powered by <a href="https://www.bigcommerce.com?utm_source=merchant&amp;utm_medium=poweredbyBC" rel="nofollow" target="_blank">BigCommerce</a>.</span>
                </p>
            </div>
    </div>
</footer>
    



<div class="newsletterPopup-overlay">
    <div class="newsletterPopup">
        <a href="#" class="newsletterPopup-dismiss modal-close" aria-label="Close" role="button">
            <span aria-hidden="true">&#215;</span>
        </a>
            <img class="newsletterPopup-image" src="https://cdn11.bigcommerce.com/s-w3d4ziaaha/content/img/newsletter.jpg">
        <h2 class="newsletterPopup-title">
                Configurable Newsletter Popup
        </h2>
        <p class="newsletterPopup-intro">
                Built into the theme and controlled through theme editor
        </p>
        <form class="form" action="/subscribe.php" method="post">
            <fieldset class="form-fieldset">
                <input type="hidden" name="action" value="subscribe">
                <input type="hidden" name="nl_first_name" value="bc">
                <input type="hidden" name="check" value="1">
                <div class="form-field">
                    <label class="form-label is-srOnly" for="nl_email">Email Address</label>
                    <div class="form-prefixPostfix wrap">
                        <input class="form-input" name="nl_email" type="email" value="" placeholder="Your email address">
                        <input class="button button--primary form-prefixPostfix-button--postfix" type="submit" value="Subscribe">
                    </div>
                </div>
            </fieldset>
        </form>
        <a class="newsletterPopup-dismiss newsletterPopup-dismiss--text" href="#">No thanks</a>
    </div>
</div>

        <script>window.__webpack_public_path__ = "https://cdn11.bigcommerce.com/s-w3d4ziaaha/stencil/282ab9e0-1112-0137-0bde-23fb93fa4dc9/dist/";</script>
        <script src="https://cdn11.bigcommerce.com/s-w3d4ziaaha/stencil/282ab9e0-1112-0137-0bde-23fb93fa4dc9/dist/theme-bundle.main.js"></script>

        <script>
            // Exported in app.js
            window.stencilBootstrap("cart", "{\"themeSettings\":{\"add_to_cart_mode\":\"dropdown\",\"alert-backgroundColor\":\"#ffffff\",\"alert-color\":\"#000000\",\"alert-color-alt\":\"#ffffff\",\"alternative_card_panel_bg\":\"#e2e2e2\",\"alternative_card_panel_text\":\"#000000\",\"alternative_card_panels\":false,\"applePay-button\":\"black\",\"blockquote-cite-font-color\":\"#999999\",\"blog_listing_size\":\"420x420\",\"blog_size\":\"800x800\",\"body-bg\":\"#ffffff\",\"body-font\":\"Google_Open+Sans_400\",\"brand_size\":\"300x300\",\"brandpage_products_per_page\":24,\"breadcrumbs_on_mobile\":\"show\",\"button--default-borderColor\":\"#a0be71\",\"button--default-borderColorActive\":\"#b3cb8d\",\"button--default-borderColorHover\":\"#90ab65\",\"button--default-color\":\"#90ab65\",\"button--default-colorActive\":\"#b3cb8d\",\"button--default-colorHover\":\"#90ab65\",\"button--disabled-backgroundColor\":\"#dadada\",\"button--disabled-borderColor\":\"transparent\",\"button--disabled-color\":\"#ffffff\",\"button--icon-svg-color\":\"#ffffff\",\"button--primary-backgroundColor\":\"#a0be71\",\"button--primary-backgroundColorActive\":\"#b3cb8d\",\"button--primary-backgroundColorHover\":\"#90ab65\",\"button--primary-color\":\"#ffffff\",\"button--primary-colorActive\":\"#ffffff\",\"button--primary-colorHover\":\"#ffffff\",\"card--alternate-backgroundColor\":\"#ffffff\",\"card--alternate-borderColor\":\"#ffffff\",\"card--alternate-color--hover\":\"#ffffff\",\"card-figcaption-button-background\":\"#ffffff\",\"card-figcaption-button-color\":\"#666666\",\"card-title-color\":\"#333333\",\"card-title-color-hover\":\"#000000\",\"card_button_style\":\"square\",\"carousel-arrow-bgColor\":\"#c6d8aa\",\"carousel-arrow-borderColor\":\"#c6d8aa\",\"carousel-arrow-color\":\"#ffffff\",\"carousel-bgColor\":\"#ffffff\",\"carousel-description-color\":\"#000000\",\"carousel-dot-bgColor\":\"#c6d8aa\",\"carousel-dot-color\":\"#dadada\",\"carousel-dot-color-active\":\"#a0be71\",\"carousel-title-color\":\"#000000\",\"carousel-type\":\"standard\",\"cart_icon\":\"bag\",\"categorypage_products_per_page\":24,\"checkRadio-backgroundColor\":\"#ffffff\",\"checkRadio-borderColor\":\"#999999\",\"checkRadio-color\":\"#373737\",\"color-black\":\"#000000\",\"color-error\":\"#cc4749\",\"color-errorLight\":\"#ffdddd\",\"color-grey\":\"#999999\",\"color-greyDark\":\"#696969\",\"color-greyDarker\":\"#333333\",\"color-greyDarkest\":\"#000000\",\"color-greyLight\":\"#999999\",\"color-greyLighter\":\"#dadada\",\"color-greyLightest\":\"#e5e5e5\",\"color-greyMedium\":\"#757575\",\"color-info\":\"#f1a500\",\"color-infoLight\":\"#fffdea\",\"color-primary\":\"#333333\",\"color-primaryDark\":\"#1a1a1a\",\"color-primaryDarker\":\"#000000\",\"color-primaryLight\":\"#999999\",\"color-secondary\":\"#ffffff\",\"color-secondaryDark\":\"#e5e5e5\",\"color-secondaryDarker\":\"#dadada\",\"color-success\":\"#008a06\",\"color-successLight\":\"#d5ffd8\",\"color-textBase\":\"#333333\",\"color-textBase--active\":\"#000000\",\"color-textBase--hover\":\"#000000\",\"color-textHeading\":\"#000000\",\"color-textLink\":\"#333333\",\"color-textLink--active\":\"#000000\",\"color-textLink--hover\":\"#000000\",\"color-textSecondary\":\"#666666\",\"color-textSecondary--active\":\"#333333\",\"color-textSecondary--hover\":\"#333333\",\"color-warning\":\"#f1a500\",\"color-warningLight\":\"#fffdea\",\"color-white\":\"#ffffff\",\"color-whitesBase\":\"#dadada\",\"color_badge_product_sale_badges\":\"#007dc6\",\"color_hover_product_sale_badges\":\"#000000\",\"color_text_product_sale_badges\":\"#ffffff\",\"container-border-global-color-base\":\"#dadada\",\"container-fill-base\":\"#ffffff\",\"container-fill-dark\":\"#e5e5e5\",\"conversion_optimization_mode\":false,\"custom_product_label_backgroundColor\":\"#a0be71\",\"custom_product_label_text_color\":\"#ffffff\",\"default_image_brand\":\"/assets/img/BrandDefault.gif\",\"default_image_gift_certificate\":\"/assets/img/GiftCertificate.png\",\"default_image_product\":\"/assets/img/ProductDefault.gif\",\"dropdown--quickSearch-backgroundColor\":\"#e5e5e5\",\"dropdown--wishList-backgroundColor\":\"#e5e5e5\",\"e\":\"Calm\",\"elfsight_instagram_app_code\":\"\",\"enable_animations\":false,\"enable_circular_swatches\":true,\"enable_editorial_mode\":true,\"enable_elfsight_instagram_feed\":false,\"enable_embedded_twitter_feed\":false,\"enable_gradients\":false,\"enable_image_hover_switcher\":true,\"enable_infinite_scrolling\":false,\"enable_instagram_feed\":true,\"enable_simple_footer\":true,\"enable_simple_header\":true,\"enable_sticky_navigation\":true,\"enclose_category_menu\":false,\"enclosed_category_menu_name\":\"Shop Online\",\"featured_category_columns\":4,\"featured_category_name\":\"Featured\",\"fontSize-h1\":30,\"fontSize-h2\":28,\"fontSize-h3\":24,\"fontSize-h4\":20,\"fontSize-h5\":16,\"fontSize-h6\":16,\"fontSize-root\":16,\"footer-backgroundColor\":\"#ffffff\",\"footer-buttonColor\":\"#a0be71\",\"footer-buttonColorActive\":\"#b3cb8d\",\"footer-buttonColorHover\":\"#90ab65\",\"footer-buttonTextColor\":\"#ffffff\",\"footer-buttonTextColorActive\":\"#ffffff\",\"footer-buttonTextColorHover\":\"#ffffff\",\"footer-headingColor\":\"#000000\",\"footer-iconColor\":\"#000000\",\"footer-iconColorHover\":\"#373737\",\"footer-inputBackgroundColor\":\"#ffffff\",\"footer-inputBorderColor\":\"#dadada\",\"footer-linkColor\":\"#373737\",\"footer-linkColorActive\":\"#696969\",\"footer-linkColorHover\":\"#696969\",\"footer-textColor\":\"#000000\",\"form-label-font-color\":\"#666666\",\"gallery_size\":\"300x300\",\"geotrust_ssl_common_name\":\"\",\"geotrust_ssl_seal_size\":\"M\",\"global_banner_backgroundColor\":\"#dadada\",\"global_banner_foregroundColor\":\"#607244\",\"global_banner_icon_1\":\"fas fa-comment\",\"global_banner_icon_2\":\"fas fa-ship\",\"global_banner_icon_3\":\"fas fa-tag\",\"global_banner_link_1\":\"/juice/\",\"global_banner_link_2\":\"/breakfast/\",\"global_banner_link_3\":\"/meals/\",\"global_banner_message_1\":\"Global Message Banner Included\",\"global_banner_message_2\":\"Over 50 Icons to Choose From\",\"global_banner_message_3\":\"Each Message Can Link to Content\",\"gradient_finish\":\"#5961f9\",\"gradient_start\":\"#ee9ae5\",\"gradient_text\":\"#ffffff\",\"grid_swatch_option_size\":\"10x10\",\"header-backgroundColor\":\"#ffffff\",\"headings-font\":\"Google_Work+Sans_300\",\"hero_align\":\"center\",\"hero_width\":\"contain\",\"hide_category_image_on_categories\":true,\"hide_category_view_all\":false,\"hide_content_navigation\":true,\"hide_featured_category_names\":false,\"hide_featured_category_title\":true,\"hide_logo_on_sticky_navigation\":false,\"hide_navigation_featured_categories\":true,\"hide_product_count_on_category\":false,\"home_featured_products_carousel\":true,\"home_new_products_carousel\":true,\"home_top_products_carousel\":true,\"homepage_blog_posts_column_count\":4,\"homepage_blog_posts_count\":4,\"homepage_featured_products_column_count\":4,\"homepage_featured_products_count\":8,\"homepage_new_products_column_count\":4,\"homepage_new_products_count\":8,\"homepage_show_carousel\":true,\"homepage_show_carousel_arrows\":true,\"homepage_stretch_carousel_images\":false,\"homepage_top_products_column_count\":4,\"homepage_top_products_count\":8,\"icon-color\":\"#a0be71\",\"icon-color-hover\":\"#90ab65\",\"icon-ratingEmpty\":\"#c6d8aa\",\"icon-ratingFull\":\"#a0be71\",\"input-bg-color\":\"#ffffff\",\"input-border-color\":\"#dadada\",\"input-border-color-active\":\"#a0be71\",\"input-disabled-bg\":\"#e5e5e5\",\"input-font-color\":\"#000000\",\"instagram_access_token\":\"8192799569.b776f01.b3abd2ad49a14afb9b95d9aa130b134a\",\"instagram_columns_count\":4,\"instagram_posts_count\":4,\"label-backgroundColor\":\"#a0be71\",\"label-color\":\"#ffffff\",\"loadingOverlay-backgroundColor\":\"#ffffff\",\"logo-font\":\"Google_Work+Sans_300\",\"logo-position\":\"center\",\"logo_fontSize\":28,\"logo_size\":\"200x50\",\"max_page_width\":\"1800\",\"mobile_navigation_background_color\":\"#dadada\",\"mobile_navigation_link_color\":\"#000000\",\"n\":\"Covent Garden\",\"navPages-backgroundColor\":\"#000000\",\"navPages-color\":\"#ffffff\",\"navPages-color-hover\":\"#dadada\",\"navPages-sticky-backgroundColor\":\"#ffffff\",\"navPages-sticky-color\":\"#000000\",\"navPages-sticky-color-hover\":\"#373737\",\"navPages-subMenu-background-color-hover\":\"#fafafa\",\"navPages-subMenu-backgroundColor\":\"#e5e5e5\",\"navPages-subMenu-color\":\"#000000\",\"navPages-subMenu-color-hover\":\"#373737\",\"navPages-subMenu-separatorColor\":\"#dadada\",\"navUser-color\":\"#373737\",\"navUser-color-hover\":\"#696969\",\"navUser-dropdown-backgroundColor\":\"#ffffff\",\"navUser-dropdown-borderColor\":\"#dadada\",\"navUser-indicator-backgroundColor\":\"#373737\",\"navigation_design\":\"simple\",\"newsletter_popup_backgroundColor\":\"#ffffff\",\"newsletter_popup_close_color\":\"#373737\",\"newsletter_popup_delay\":15000,\"newsletter_popup_image\":\"newsletter.jpg\",\"newsletter_popup_intro\":\"Built into the theme and controlled through theme editor\",\"newsletter_popup_reappear_after\":3,\"newsletter_popup_text_color\":\"#000000\",\"newsletter_popup_title\":\"Configurable Newsletter Popup\",\"optimizedCheckout-backgroundImage\":\"\",\"optimizedCheckout-backgroundImage-size\":\"1000x400\",\"optimizedCheckout-body-backgroundColor\":\"#ffffff\",\"optimizedCheckout-buttonPrimary-backgroundColor\":\"#a0be71\",\"optimizedCheckout-buttonPrimary-backgroundColorActive\":\"#000000\",\"optimizedCheckout-buttonPrimary-backgroundColorDisabled\":\"#dadada\",\"optimizedCheckout-buttonPrimary-backgroundColorHover\":\"#90ab65\",\"optimizedCheckout-buttonPrimary-borderColor\":\"#a0be71\",\"optimizedCheckout-buttonPrimary-borderColorActive\":\"transparent\",\"optimizedCheckout-buttonPrimary-borderColorDisabled\":\"transparent\",\"optimizedCheckout-buttonPrimary-borderColorHover\":\"#90ab65\",\"optimizedCheckout-buttonPrimary-color\":\"#ffffff\",\"optimizedCheckout-buttonPrimary-colorActive\":\"#ffffff\",\"optimizedCheckout-buttonPrimary-colorDisabled\":\"#ffffff\",\"optimizedCheckout-buttonPrimary-colorHover\":\"#ffffff\",\"optimizedCheckout-buttonPrimary-font\":\"Google_Montserrat_400\",\"optimizedCheckout-buttonSecondary-backgroundColor\":\"#ffffff\",\"optimizedCheckout-buttonSecondary-backgroundColorActive\":\"#ffffff\",\"optimizedCheckout-buttonSecondary-backgroundColorHover\":\"#ffffff\",\"optimizedCheckout-buttonSecondary-borderColor\":\"#a0be71\",\"optimizedCheckout-buttonSecondary-borderColorActive\":\"#b3cb8d\",\"optimizedCheckout-buttonSecondary-borderColorHover\":\"#90ab65\",\"optimizedCheckout-buttonSecondary-color\":\"#90ab65\",\"optimizedCheckout-buttonSecondary-colorActive\":\"#b3cb8d\",\"optimizedCheckout-buttonSecondary-colorHover\":\"#90ab65\",\"optimizedCheckout-buttonSecondary-font\":\"Google_Montserrat_400\",\"optimizedCheckout-colorFocus\":\"#a0be71\",\"optimizedCheckout-contentPrimary-color\":\"#000000\",\"optimizedCheckout-contentPrimary-font\":\"Google_Montserrat_400\",\"optimizedCheckout-contentSecondary-color\":\"#757575\",\"optimizedCheckout-contentSecondary-font\":\"Google_Montserrat_400\",\"optimizedCheckout-discountBanner-backgroundColor\":\"#dadada\",\"optimizedCheckout-discountBanner-iconColor\":\"#373737\",\"optimizedCheckout-discountBanner-textColor\":\"#373737\",\"optimizedCheckout-form-textColor\":\"#000000\",\"optimizedCheckout-formChecklist-backgroundColor\":\"#ffffff\",\"optimizedCheckout-formChecklist-backgroundColorSelected\":\"#f5f5f5\",\"optimizedCheckout-formChecklist-borderColor\":\"#dadada\",\"optimizedCheckout-formChecklist-color\":\"#373737\",\"optimizedCheckout-formField-backgroundColor\":\"#ffffff\",\"optimizedCheckout-formField-borderColor\":\"#dadada\",\"optimizedCheckout-formField-errorColor\":\"#cc4749\",\"optimizedCheckout-formField-inputControlColor\":\"#a0be71\",\"optimizedCheckout-formField-placeholderColor\":\"#696969\",\"optimizedCheckout-formField-shadowColor\":\"#e5e5e5\",\"optimizedCheckout-formField-textColor\":\"#000000\",\"optimizedCheckout-header-backgroundColor\":\"#ffffff\",\"optimizedCheckout-header-borderColor\":\"#dddddd\",\"optimizedCheckout-header-textColor\":\"#000000\",\"optimizedCheckout-headingPrimary-color\":\"#000000\",\"optimizedCheckout-headingPrimary-font\":\"Google_Montserrat_400\",\"optimizedCheckout-headingSecondary-color\":\"#373737\",\"optimizedCheckout-headingSecondary-font\":\"Google_Montserrat_400\",\"optimizedCheckout-link-color\":\"#000000\",\"optimizedCheckout-link-font\":\"Google_Montserrat_400\",\"optimizedCheckout-link-hoverColor\":\"#373737\",\"optimizedCheckout-loadingToaster-backgroundColor\":\"#373737\",\"optimizedCheckout-loadingToaster-textColor\":\"#ffffff\",\"optimizedCheckout-logo\":\"\",\"optimizedCheckout-logo-position\":\"left\",\"optimizedCheckout-logo-size\":\"250x100\",\"optimizedCheckout-orderSummary-backgroundColor\":\"#ffffff\",\"optimizedCheckout-orderSummary-borderColor\":\"#dadada\",\"optimizedCheckout-show-backgroundImage\":false,\"optimizedCheckout-show-logo\":\"none\",\"optimizedCheckout-step-backgroundColor\":\"#dadada\",\"optimizedCheckout-step-borderColor\":\"#dddddd\",\"optimizedCheckout-step-textColor\":\"#373737\",\"overlay-backgroundColor\":\"#373737\",\"pace-progress-backgroundColor\":\"#999999\",\"paymentbuttons-paypal-color\":\"gold\",\"paymentbuttons-paypal-fundingicons\":false,\"paymentbuttons-paypal-label\":\"checkout\",\"paymentbuttons-paypal-layout\":\"horizontal\",\"paymentbuttons-paypal-shape\":\"pill\",\"paymentbuttons-paypal-size\":\"small\",\"paymentbuttons-paypal-tagline\":true,\"pdp-non-sale-price-label\":\"Was:\",\"pdp-price-label\":\"\",\"pdp-retail-price-label\":\"MSRP:\",\"pdp-sale-price-label\":\"Now:\",\"percentage_saving_backgroundColor\":\"#a0be71\",\"percentage_saving_text_color\":\"#ffffff\",\"price_ranges\":true,\"product_list_display_mode\":\"grid\",\"product_sale_badges\":\"none\",\"product_size\":\"800x800\",\"productgallery_size\":\"500x500\",\"productpage_related_products_count\":10,\"productpage_reviews_count\":10,\"productpage_similar_by_views_count\":10,\"productpage_videos_count\":8,\"productthumb_size\":\"100x100\",\"productview_thumb_size\":\"50x50\",\"rename_warranty_field\":\"\",\"replace_utility_menu_with_icons\":true,\"restrict_to_login\":false,\"sale_tag_backgroundColor\":\"#a0be71\",\"sale_tag_text_color\":\"#ffffff\",\"searchpage_products_per_page\":24,\"secondary-font\":\"Google_Work+Sans_300\",\"select-arrow-color\":\"#373737\",\"select-bg-color\":\"#ffffff\",\"selling_fast_tag_backgroundColor\":\"#a0be71\",\"selling_fast_tag_text_color\":\"#ffffff\",\"shop_by_brand_show_footer\":true,\"shop_by_brand_show_navigation\":false,\"shop_by_price_visibility\":true,\"show_accept_amazon_pay\":true,\"show_accept_amex\":true,\"show_accept_apple_pay\":true,\"show_accept_diners\":false,\"show_accept_discover\":false,\"show_accept_jcb\":false,\"show_accept_klarna\":true,\"show_accept_mastercard\":true,\"show_accept_mcsc\":true,\"show_accept_paypal\":true,\"show_accept_vbv\":true,\"show_accept_visa\":true,\"show_accept_vp\":false,\"show_articles_on_homepage\":true,\"show_availability_on_grid\":false,\"show_blog_card_author\":true,\"show_blog_card_summary\":true,\"show_copyright_footer\":true,\"show_custom_fields_on_grid\":false,\"show_custom_product_labels\":true,\"show_designed_by\":true,\"show_global_banner\":true,\"show_homepage_featured_categories\":true,\"show_newsletter_popup\":true,\"show_payment_methods\":true,\"show_payment_methods_in_cart\":true,\"show_percentage_saving\":true,\"show_phone_number_in_header\":true,\"show_powered_by\":true,\"show_powered_by_braintree\":false,\"show_powered_by_sage\":false,\"show_powered_by_skrill\":false,\"show_powered_by_square\":false,\"show_powered_by_stripe\":false,\"show_product_description_below\":true,\"show_product_details_tabs\":false,\"show_product_dimensions\":false,\"show_product_quantity_box\":true,\"show_product_quick_view\":true,\"show_product_weight\":true,\"show_sale_tags\":true,\"show_selected_option_on_label\":true,\"show_selling_fast_tags\":true,\"show_sizes_on_grid\":false,\"show_stock_level_on_grid\":false,\"show_subcategories_as_grid\":false,\"show_swatches_on_grid\":false,\"show_upc_on_product\":false,\"show_wishlist_in_navigation\":true,\"show_wishlist_on_grid\":true,\"simple-footer-keylineColor\":\"#dadada\",\"simple-footer-newsletter-backgroundColor\":\"#ffffff\",\"simple-footer-newsletter-textColor\":\"#000000\",\"size_label\":\"Size\",\"social_icon_placement_bottom\":true,\"social_icon_placement_top\":false,\"spinner-borderColor-dark\":\"#999999\",\"spinner-borderColor-light\":\"#ffffff\",\"storeName-color\":\"#000000\",\"subcategories_grid_column_count\":4,\"supported_card_type_icons\":[\"american_express\",\"diners\",\"discover\",\"mastercard\",\"visa\"],\"svg_logo\":\"healthful-logo.svg\",\"swatch_option_size\":\"20x20\",\"thumb_size\":\"100x100\",\"twitter_collection_id\":\"\",\"twitter_display_type\":\"\",\"twitter_posts_count\":6,\"twitter_screen_name\":\"\",\"v\":\"2.1.0\",\"zoom_size\":\"1280x1280\"},\"genericError\":\"Oops! Something went wrong.\",\"maintenanceMode\":{\"header\":null,\"message\":null,\"notice\":null,\"password\":null,\"securePath\":\"https://covent-garden-calm-demo.mybigcommerce.com\"},\"urls\":{\"account\":{\"add_address\":\"/account.php?action=add_shipping_address\",\"addresses\":\"/account.php?action=address_book\",\"details\":\"/account.php?action=account_details\",\"inbox\":\"/account.php?action=inbox\",\"index\":\"/account.php\",\"orders\":{\"all\":\"/account.php?action=order_status\",\"completed\":\"/account.php?action=view_orders\",\"save_new_return\":\"/account.php?action=save_new_return\"},\"payment_methods\":{\"all\":\"/account.php?action=payment_methods\"},\"recent_items\":\"/account.php?action=recent_items\",\"returns\":\"/account.php?action=view_returns\",\"send_message\":\"/account.php?action=send_message\",\"update_action\":\"/account.php?action=update_account\",\"wishlists\":{\"add\":\"/wishlist.php?action=addwishlist\",\"all\":\"/wishlist.php\",\"delete\":\"/wishlist.php?action=deletewishlist\",\"edit\":\"/wishlist.php?action=editwishlist\"}},\"auth\":{\"check_login\":\"/login.php?action=check_login\",\"create_account\":\"/login.php?action=create_account\",\"forgot_password\":\"/login.php?action=reset_password\",\"login\":\"/login.php\",\"logout\":\"/login.php?action=logout\",\"save_new_account\":\"/login.php?action=save_new_account\",\"save_new_password\":\"/login.php?action=save_new_password\",\"send_password_email\":\"/login.php?action=send_password_email\"},\"brands\":\"https://covent-garden-calm-demo.mybigcommerce.com/brands/\",\"cart\":\"/cart.php\",\"checkout\":{\"multiple_address\":\"/checkout.php?action=multiple\",\"single_address\":\"/checkout.php\"},\"compare\":\"/compare\",\"contact_us_submit\":\"/pages.php?action=sendContactForm\",\"gift_certificate\":{\"balance\":\"/giftcertificates.php?action=balance\",\"purchase\":\"/giftcertificates.php\",\"redeem\":\"/giftcertificates.php?action=redeem\"},\"home\":\"https://covent-garden-calm-demo.mybigcommerce.com/\",\"product\":{\"post_review\":\"/postreview.php\"},\"rss\":{\"products\":[]},\"search\":\"/search.php\",\"sitemap\":\"/sitemap.php\",\"subscribe\":{\"action\":\"/subscribe.php\"}},\"secureBaseUrl\":\"https://covent-garden-calm-demo.mybigcommerce.com\",\"template\":\"pages/cart\",\"enableAnimations\":false,\"enableNewsletterPopup\":true,\"newsletterPopupDelay\":15000,\"reappearAfter\":3,\"pageType\":\"cart\"}").load();
        </script>

        <script type="text/javascript" src="https://cdn11.bigcommerce.com/r-6d3ad06da9906c7b44b28d560a43353105957b49/javascript/visitor_stencil.js"></script>

        <!-- snippet location footer -->
    </body>
</html>
